import base64
import os
import cv2
import numpy as np
from sklearn.cluster import KMeans


def preprocess_image(image):

    # Converter para escala de cinza
    gray = cv2.cvtColor(image, cv2.COLOR_BGR2GRAY)
    
    # Aplicar desfoque Gaussian para reduzir ruídos
    blurred = cv2.GaussianBlur(gray, (5, 5), 0)
    
    # Aplicar limiar adaptativo para destacar regiões de interesse
    _, binary_mask = cv2.threshold(blurred, 0, 255, cv2.THRESH_BINARY + cv2.THRESH_OTSU)

    # Inverter a máscara binária (opcional, dependendo da imagem)
    binary_mask = cv2.bitwise_not(binary_mask)

    # Aplicar operações morfológicas para refinar a máscara
    kernel = cv2.getStructuringElement(cv2.MORPH_ELLIPSE, (5, 5))
    refined_mask = cv2.morphologyEx(binary_mask, cv2.MORPH_CLOSE, kernel, iterations=1)
    refined_mask = cv2.morphologyEx(refined_mask, cv2.MORPH_OPEN, kernel, iterations=1)

    return refined_mask


def process_image(image: np.ndarray, lower: tuple, upper: tuple, nucleus_color: tuple, contour_color: tuple) -> tuple:

    num_clusters=3
    # Certifique-se de que o diretório 'processing-output' existe
    output_dir = os.path.join(os.path.dirname(__file__), 'processing-output')
    os.makedirs(output_dir, exist_ok=True)

    # iniciando variaveis
    # image = cv2.imread(image_path)
    height, width, chanels = image.shape[:3]
    black_image_1_chanel = np.zeros((height, width, 1), dtype="uint8")
    black_image_3_chanel = cv2.cvtColor(black_image_1_chanel, cv2.COLOR_GRAY2RGB)
    cells = image[:, :, 0]

    # Iniciando vars que serao usadas para erosao
    kernel = np.ones((9, 9), np.uint8)
    iterac = 0
    contornos = -1

    # cria mascara vazia com o tamanho da imagem original
    mask_removed_contours = np.zeros(image.shape[:2], dtype=image.dtype)

    # cria variaveis para criar borda preta de 1 pixel ao redor da imagem
    row, col = image.shape[:2]
    bottom = image[row-2:row, 0:col]
    mean = cv2.mean(bottom)[0]
    bordersize = 1
    border = cv2.copyMakeBorder(image, top=bordersize, bottom=bordersize, left=bordersize,
                                right=bordersize, borderType=cv2.BORDER_CONSTANT, value=[mean, mean, mean])

    pixels_to_um = 0.454  # 1 pixel = 454 nm
    """
    Segmenta a imagem com base nos clusters de cor.
    """

    # Pré-processar a imagem para criar a máscara do plano de fundo
    mask = preprocess_image(image)

    # Calcular os limites de cor dinamicamente
    #lower, upper = calculate_boundaries(image, mask, num_clusters)

    # Criar a máscara final e aplicar a segmentação
    lower = np.array(lower, dtype="uint8")
    upper = np.array(upper, dtype="uint8")
    final_mask = cv2.inRange(image, lower, upper)
    segmented_image = cv2.bitwise_and(image, image, mask=final_mask)


    # Grayscale
    gray = cv2.cvtColor(segmented_image, cv2.COLOR_BGR2GRAY)

    
    # Passo 1. Suavização Mediana
    blur = cv2.medianBlur(gray, 5)


    # Passo 2. Binarização global
    # Passo 2.a)Crio uma pequena borda preta em torno da imagem para identificar e fechar os contornos das bordas
    ret2, th2 = cv2.threshold(blur, 1, 255, cv2.THRESH_BINARY)
    border_init = cv2.copyMakeBorder(
        th2, top=5, bottom=5, left=5, right=5, borderType=cv2.BORDER_CONSTANT, value=[0, 0, 0])


    # Passo 3. Transformações Morfológicas
    kernel2 = np.ones((3, 3), np.uint8)

    morph = cv2.morphologyEx(border_init, cv2.MORPH_CLOSE, kernel2)
    morph_out = cv2.morphologyEx(morph, cv2.MORPH_OPEN, kernel2)

    # Passo 4: Detecção de bordas com Canny
    edged = cv2.Canny(morph_out, 70, 255)


    # Passo 5: Encontra os contornos
    contours, hierarchy = cv2.findContours(edged, cv2.RETR_EXTERNAL, cv2.CHAIN_APPROX_NONE)

    contours_filtered = [c for c in contours if cv2.contourArea(c) > 400]  # Filtra contornos com área maior que 600 pixels

    contours_img = cv2.drawContours(image, contours_filtered, -1, contour_color, 3)
    total_contours_before = str(len(contours_filtered))

    crowded_areas = []  # Salva contornos das areas aglomeradas
    no_crowded_areas = []

    # itera sobre cada contorno do conjunto e contornos identificados na imagem
    for item in contours_filtered:
        area = cv2.contourArea(item)

        if area > 6500:  # area de 6500 definida por amostragem com base na resolução da imagem dos casos apresentadas. Valor pode ser modificado.
            crowded_areas.append(item)
            cluster_area = 'true'
        else:
            cluster_area = 'false'
            no_crowded_areas.append(item)

        perimeter = cv2.arcLength(item, True)
        max_coord = str(item.max())
        min_coord = str(item.min())
        shape = str(item.shape)
        shape = shape.replace('(', '')
        shape = shape.replace(')', '')
        size = str(item.size)
        pixels_number = str((item.size)/2)
        moment = (cv2.moments(item))

    crowded_img = cv2.drawContours(
        black_image_3_chanel, crowded_areas, -1, contour_color, 3)
    no_crowded_img = cv2.drawContours(
        black_image_3_chanel, no_crowded_areas, -1, contour_color, 3)



    # 1. Preenchimento dos contornos identificados como aglomeracoes
    crowded_img_filled_overlay = cv2.drawContours(
        crowded_img, crowded_areas, contourIdx=-1, color=(255, 255, 255), thickness=-1)


    black = cv2.cvtColor(black_image_1_chanel, cv2.COLOR_GRAY2RGB)
    crowded_img_filled = cv2.drawContours(
        black, crowded_areas, contourIdx=-1, color=(255, 255, 255), thickness=-1)


    # Passo 6: Identificadas e separadas as area com possiveis aglomerações:
    # a)Aplicar n erosoes nos contornos até que vire a area corresponda a um tamanho n<area<m


    # 1. Verifica quantos contornos há antes da erosão
    edged_init = cv2.Canny(crowded_img_filled, 70, 255)
    contours_init, h_init = cv2.findContours(
        edged_init, cv2.RETR_EXTERNAL, cv2.CHAIN_APPROX_NONE)
    contornos = str(len(contours_init))
    #print("")
    #print("Contornos encontrados para iniciar iteração: ", str(contornos))

    # Initialize img variable
    img = np.zeros(image.shape[:2], dtype=image.dtype)

    # 2. Se houve contornos, vai erodir a imagem até que não haja mais
    while contornos != '0':
        # cria uma máscara vazia para os contornos que continuarão na iteração, isso evita que os contornos sejam redesenhados na mesma imagem, causando sempre a mesma imagem que a inicial
        mask_eroded = np.zeros(image.shape[:2], dtype=image.dtype)

        # 3. Erode a imagem por 1 iteração
        if iterac != 0:  # 3.a) Se for a primeira iteração, pega a imagem da iteração anterior
            gray = cv2.cvtColor(img, cv2.COLOR_BGR2GRAY)
            eroded = cv2.erode(gray, kernel, iterations=1)
        else:  # 3.b)Se for a primeira iteração, pega a imagem carregada externamente
            eroded = cv2.erode(crowded_img_filled, kernel, iterations=1)


        kernel = np.ones((5, 5), np.float32)/25
        dst = cv2.filter2D(eroded, -1, kernel)
        ret, thresh1 = cv2.threshold(dst, 127, 255, cv2.THRESH_BINARY)

        # 4. Pega as bordas do contorno, e conta somente os contornos externos
        edged = cv2.Canny(thresh1, 70, 255)
        contours, hier = cv2.findContours(
            edged, cv2.RETR_EXTERNAL, cv2.CHAIN_APPROX_TC89_KCOS)
        #print("Iteração: ", str(iterac), " | Contornos totais: ", str(len(contours)))
        contornos = str(len(contours))

        # 5. Vai verificar a área dos n contornos encontrados, para saber se é necessário mais iterações ou não
        for index, c in enumerate(contours):

            # 7.a) Se a área do contorno for entre 100 e 1000 pixels, o contorno será removido
            # *Tamanho de 100 a 1000 pixels definido por amostragem de acordo com a resolução das imagens de caso
            # apresentadas. Valores podem ser modificados.
            if cv2.contourArea(c) > 100 and cv2.contourArea(c) < 1000:
                cv2.drawContours(mask_removed_contours, [c], 0, (255), -1)
            else:  # 7.b)Se não será salvo para que a iteração continue
                cv2.drawContours(mask_eroded, [c], 0, (255), thickness=-1)

        border_out = cv2.copyMakeBorder(mask_eroded, top=bordersize, bottom=bordersize, left=bordersize,
                                        right=bordersize, borderType=cv2.BORDER_CONSTANT, value=[mean, mean, mean])

    # Reset img variable
        img = np.zeros(image.shape, dtype=image.dtype)
        img = cv2.cvtColor(border_out, cv2.COLOR_GRAY2BGR)

        iterac += 1
        #print("")


    # Passo 7: unir a imagem erodida com a imagem sem possiveis aglomerações e contar os contornos totais
    edged_desaglomeracoes = cv2.Canny(mask_removed_contours, 70, 255)
    contours_out, h_out = cv2.findContours(edged_desaglomeracoes, cv2.RETR_EXTERNAL, cv2.CHAIN_APPROX_TC89_KCOS)
    

    #mask_out = np.zeros(image.shape[:3], dtype=image.dtype)
    mask_out = image.copy()
    cv2.drawContours(mask_out, contours_out, -1, nucleus_color, thickness=-1)

    dif = len(contours_out)-len(crowded_areas)
    contornos_finais = (int(total_contours_before) + dif);
    return mask_out, contornos_finais


def process_image_with_boundaries(image_path, limiteInferiorPositivo, limiteSuperiorPositivo, limiteInferiorNegativo, limiteSuperiorNegativo):
    # Validar os limites recebidos
    boundaries = validate_boundaries(
        limiteInferiorPositivo,
        limiteSuperiorPositivo,
        limiteInferiorNegativo,
        limiteSuperiorNegativo
    )

    # Atribuir os limites validados
    limiteInferiorPositivo = boundaries["limiteInferiorPositivo"]
    limiteSuperiorPositivo = boundaries["limiteSuperiorPositivo"]
    limiteInferiorNegativo = boundaries["limiteInferiorNegativo"]
    limiteSuperiorNegativo = boundaries["limiteSuperiorNegativo"]

    
    # Verificar se o arquivo existe
    if not os.path.exists(image_path):
        print(f"Erro: O arquivo {image_path} não foi encontrado.")
        return

    # Ler a imagem
    img = cv2.imread(image_path)
    if img is None:
        print("Erro: Falha ao carregar a imagem. Verifique se o arquivo é uma imagem válida.")
        return

    # Criar diretório para salvar as imagens processadas
    output_dir = "./output_images"
    os.makedirs(output_dir, exist_ok=True)

    output_image_path_positive = os.path.join(output_dir, "processed_image_positive.jpg")
    output_image_path_negative = os.path.join(output_dir, "processed_image_negative.jpg")
    output_image_path_merged = os.path.join(output_dir, "processed_image_merged.jpg")

    positive_nucleus_color = (255, 105, 180)
    positive_contour_color = (0, 0, 255)  # Rosa e vermelho

    # Processar a imagem para os limites positivos
    processed_image_positive, positive_contours_counting = process_image(
        img.copy(),
        limiteInferiorPositivo,
        limiteSuperiorPositivo,
        positive_nucleus_color,
        positive_contour_color,
    )

    if processed_image_positive is None or not isinstance(processed_image_positive, np.ndarray):
        print("Erro no processamento da imagem positiva. A função não retornou uma matriz válida.")
        return

    # Salvar a imagem processada positiva
    cv2.imwrite(output_image_path_positive, processed_image_positive)
    print(f"Imagem positiva processada salva em: {output_image_path_positive}")

    # Definir cores personalizadas para a imagem negativa
    negative_nucleus_color = (0, 255, 0)
    negative_contour_color = (255, 0, 0)  # Verde e azul

    # Processar a imagem para os limites negativos
    processed_image_negative, negative_contours_counting = process_image(
        img.copy(),
        limiteInferiorNegativo,
        limiteSuperiorNegativo,
        negative_nucleus_color,
        negative_contour_color,
    )

    if processed_image_negative is None or not isinstance(processed_image_negative, np.ndarray):
        print("Erro no processamento da imagem negativa. A função não retornou uma matriz válida.")
        return

    # Salvar a imagem processada negativa
    cv2.imwrite(output_image_path_negative, processed_image_negative)
    print(f"Imagem negativa processada salva em: {output_image_path_negative}")

    # Mesclar as imagens processadas
    merged_image = cv2.addWeighted(processed_image_positive, 0.5, processed_image_negative, 0.5, 1)
    cv2.imwrite(output_image_path_merged, merged_image)

    # Calcular o total de células e as porcentagens
    total_cells = positive_contours_counting + negative_contours_counting
    positive_percentage = (positive_contours_counting / total_cells) * 100 if total_cells > 0 else 0
    negative_percentage = (negative_contours_counting / total_cells) * 100 if total_cells > 0 else 0

    # Converter imagens para base64
    _, buffer_positive = cv2.imencode('.jpg', processed_image_positive)
    processed_image_positive_base64 = base64.b64encode(buffer_positive).decode('utf-8')

    _, buffer_negative = cv2.imencode('.jpg', processed_image_negative)
    processed_image_negative_base64 = base64.b64encode(buffer_negative).decode('utf-8')

    _, buffer_merged = cv2.imencode('.jpg', merged_image)
    merged_image_base64 = base64.b64encode(buffer_merged).decode('utf-8')

    # Retornar os resultados
    return {
        "positive_contours_counting": positive_contours_counting,
        "negative_contours_counting": negative_contours_counting,
        "total_cells": total_cells,
        "positive_percentage": round(positive_percentage, 2),
        "negative_percentage": round(negative_percentage, 2),
        "merged_image_base64": merged_image_base64,
        "merged_image": merged_image,
        "processed_image_positive_base64": processed_image_positive_base64,
        "processed_image_positive": processed_image_positive,
        "processed_image_negative_base64": processed_image_negative_base64,
        "processed_image_negative": processed_image_negative,
    }



def validate_boundaries(
    limiteInferiorPositivo=None,
    limiteSuperiorPositivo=None,
    limiteInferiorNegativo=None,
    limiteSuperiorNegativo=None
):
    """
    Valida os limites recebidos e aplica os valores padrão quando necessário.

    Args:
        limiteInferiorPositivo (tuple or None): Limite inferior positivo recebido.
        limiteSuperiorPositivo (tuple or None): Limite superior positivo recebido.
        limiteInferiorNegativo (tuple or None): Limite inferior negativo recebido.
        limiteSuperiorNegativo (tuple or None): Limite superior negativo recebido.

    Returns:
        dict: Dicionário contendo os limites validados.
    """
    # Limites padrão
    default_limits = {
        "limiteInferiorPositivo": (0, 0, 31),
        "limiteSuperiorPositivo": (109, 121, 150),
        "limiteInferiorNegativo": (125, 87, 72),
        "limiteSuperiorNegativo": (160, 151, 150),
    }

    # Verificar quais limites foram passados e aplicar os valores padrão quando necessário
    validated_limits = {
        "limiteInferiorPositivo": limiteInferiorPositivo if limiteInferiorPositivo is not None else default_limits["limiteInferiorPositivo"],
        "limiteSuperiorPositivo": limiteSuperiorPositivo if limiteSuperiorPositivo is not None else default_limits["limiteSuperiorPositivo"],
        "limiteInferiorNegativo": limiteInferiorNegativo if limiteInferiorNegativo is not None else default_limits["limiteInferiorNegativo"],
        "limiteSuperiorNegativo": limiteSuperiorNegativo if limiteSuperiorNegativo is not None else default_limits["limiteSuperiorNegativo"],
    }

    return validated_limits

